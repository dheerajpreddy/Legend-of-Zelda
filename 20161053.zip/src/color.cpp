#include "main.h"

const color_t COLOR_RED = { 189, 59, 21 };
const color_t COLOR_WHITE = { 232, 234, 201 };
const color_t COLOR_GREEN = { 135, 211, 124 };
const color_t COLOR_BLACK = { 52, 73, 94 };
color_t COLOR_BACKGROUND = { 185, 245, 246 };
const color_t COLOR_OCEAN_BLUE = { 0, 135, 220 };
const color_t COLOR_HEALTH_POINTS = { 85, 70, 124 };
const color_t COLOR_GIFT = { 230, 104, 91 };
const color_t COLOR_BOOSTER = { 134, 134, 134 };
const color_t COLOR_BARREL = { 163, 73, 41 };
