Graphics Assignment 2
=========================
Dheeraj Reddy Pailla, 20161053

Controls:
1. Up/Down arrow key to move forward/backward
2. Left/Right arrow keys to turn left/right
3. Space to jump
4. F to toggle to first person shooting
5. A to shoot from any view
6. C to cycle through all viewing angles

BONUS:
1. Color of sky changes regularly depending on time of day
2. Different sounds whenever objects collide with boat
3. Randomized placement of monsters and boss monster
4. Randomized gift/drop placement on killing monsters
5. Rotation of sail based on wind

License
-------
The MIT License

Copyright &copy; 2018 Dheeraj Reddy Pailla <dheerajpreddy@gmail.com>
